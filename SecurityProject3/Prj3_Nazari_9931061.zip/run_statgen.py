import statsgen

sg = statsgen.StatsGen()
sg.generate_stats('test.txt')
sg.print_stats()